#ifndef _COORDINATES_
#define _COORDINATES_

struct Coordinates {
    int row;
    int col; 
};
#endif

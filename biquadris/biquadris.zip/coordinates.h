#ifndef _COORDINATES_
#define _COORDINATES_

struct coordinates {
    int row;
    int col; 
};
#endif

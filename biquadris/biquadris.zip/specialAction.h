#ifndef _SPECIALACTION_
#define _SPECIALACTION_

class SpecialAction {
    public:
    virtual ~SpecialAction;
};
#endif

#ifndef _SPECIALACTION_
#define _SPECIALACTION_

enum SpecialAction {
    Heavy, Blind,
    ForceI, ForceJ, ForceL, ForceO, ForceS, ForceT, ForceZ,
    Shuffle
};
#endif

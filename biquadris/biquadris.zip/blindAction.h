#ifndef _BLINDACTION_
#define _BLINDACTION_

class BlindAction: public SpecialAction {};

#endif 

#ifndef __NEXTBLOCK_H__
#define __NEXTBLOCK_H__
#include <cstddef>
#include "colour.h"

struct NextBlock {
    Colour colour;
    int boardnum;
};

#endif

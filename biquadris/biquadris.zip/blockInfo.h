#ifndef _BLOCKINFO_
#define _BLOCKINFO_
#include "colour.h"

struct BlockInfo {
    int heavy;
    Colour colour;
    bool spawnDot;
};
#endif

#ifndef _COMMANDS_
#define _COMMANDS_
enum class Command {
    Left, Right, Down, ClockWise, CounterClockWise, Drop,
    LevelUp, LevelDown, NoRandom, Random, Sequence, I, J,
    L, O, S, Z, T, Restart, Blind, Heavy, Force, Hold, Shuffle
};
#endif

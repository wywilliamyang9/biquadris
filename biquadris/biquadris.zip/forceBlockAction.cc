#include "forceBlockAction.h"
ForceBlockAction::ForceBlockAction(Colour colour):
colour{colour} {}

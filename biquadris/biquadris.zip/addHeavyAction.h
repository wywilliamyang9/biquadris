#ifndef _ADDHEAVYACTION_
#define _ADDHEAVYACTION_

class AddHeavyAction: public SpecialAction {};

#endif 

#include <memory>
#include <iostream>
#include <vector>
#include <string>
using namespace std;

int main() {
	char* a{"abcdeoiajpdofa;sdf;asdnf;nalksfnlkasndflknasjkdfndffgasdflkjnalksfklanwelkfnlkawenfknawlkenflkasndfjnklasfj"};
    string b{"hi"};
    //a = b;
	cout << sizeof(char) << endl;
}


